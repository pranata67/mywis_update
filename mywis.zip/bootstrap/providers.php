<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\PublicPanelProvider::class,
    App\Providers\FillamentServiceProvider::class,
    App\Providers\UserServiceProvider::class,
];
