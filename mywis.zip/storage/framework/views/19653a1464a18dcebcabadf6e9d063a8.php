
<?php $__env->startSection('title', 'Hasil Rekomendasi Wisata'); ?>

<?php $__env->startSection('content'); ?>

<div class="py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <h2 class="text-3xl font-bold text-center mb-10">Hasil Rekomendasi Wisata</h2>

        <?php if(session('recommendations') && count(session('recommendations')) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = session('recommendations'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div x-data="{ openDetail: false }" class="card bg-base-100 shadow-xl flex flex-col h-full">
                    
                    
                    <figure>
                        <?php
                            $imageUrl = null;
                            if (is_string($item['wisata']->image) && !empty($item['wisata']->image)) {
                                $imageUrl = asset('storage/' . $item['wisata']->image);
                            } elseif (is_array($item['wisata']->image) && count($item['wisata']->image) > 0 && !empty($item['wisata']->image[0])) {
                                $imageUrl = asset('storage/' . $item['wisata']->image[0]);
                            }
                        ?>

                        <?php if($imageUrl): ?>
                            <img src="<?php echo e($imageUrl); ?>" 
                                 class="w-full h-52 object-cover" 
                                 alt="Gambar Wisata <?php echo e($item['wisata']->name); ?>">
                        <?php else: ?>
                            <div class="w-full h-52 bg-base-200 text-base-content flex items-center justify-center text-center p-4">
                                Tidak ada gambar
                            </div>
                        <?php endif; ?>
                    </figure>

                    
                    <div class="card-body p-6 flex flex-col flex-grow">
                        <h2 class="card-title">#<?php echo e($index+1); ?>: <?php echo e($item['wisata']->name); ?></h2>

                        <?php if($item['wisata']->link_gmaps): ?>
                            <a href="<?php echo e($item['wisata']->link_gmaps); ?>" target="_blank" 
                               class="link link-info inline-flex items-center text-sm mb-3">
                                <i class="fas fa-map-marker-alt mr-2"></i> Lihat di Maps
                            </a>
                        <?php endif; ?>

                        <ul class="space-y-1 mb-4 text-sm">
                            <li><span class="font-semibold">Skor:</span> <?php echo e(number_format($item['score'], 3)); ?></li>
                            <li><span class="font-semibold">Rating:</span> <?php echo e($item['details']['ulasan'] ?? 'N/A'); ?>/5</li>
                            <li><span class="font-semibold">Jarak:</span> <?php echo e(number_format($item['details']['jarak'] ?? 0, 2)); ?> km</li>
                        </ul>
                        
                        
                        <div x-show="openDetail" x-collapse class="mt-4 bg-base-200/50 rounded-md p-4 text-sm">
                            <p class="mb-3"><span class="font-semibold">Deskripsi:</span> <?php echo e($item['wisata']->deskripsi); ?></p>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                                <p class="flex items-center space-x-2"><i class="fas fa-ticket-alt w-4 text-center"></i> <span>Tiket: Rp<?php echo e(number_format($item['details']['harga_tiket'] ?? 0)); ?></span></p>
                                <p class="flex items-center space-x-2"><i class="fas fa-road w-4 text-center"></i> <span>Akses: <?php echo e(number_format($item['details']['aksesibilitas'] ?? 'N/A')); ?></span></p>
                                <p class="flex items-center space-x-2"><i class="fas fa-restroom w-4 text-center"></i> <span>Fasilitas: <?php echo e($item['details']['jumlah_fasilitas'] ?? 'N/A'); ?></span></p>
                                <p class="flex items-center space-x-2"><i class="fas fa-clock w-4 text-center"></i> <span>Operasional: <?php echo e($item['details']['waktu_operasional'] ?? 'N/A'); ?> jam</span></p>
                            </div>
                        </div>
                        
                        
                        <div class="card-actions justify-end items-center mt-auto pt-4 space-x-2">
                            
                            <?php if(isset($item['wisata']->link_profil) && !empty($item['wisata']->link_profil)): ?>
                                <a href="<?php echo e($item['wisata']->link_profil); ?>" target="_blank" class="btn btn-secondary flex-1">
                                    <i class="fas fa-external-link-alt mr-2"></i>Lihat Profil
                                </a>
                            <?php else: ?>
                                
                                <a href="<?php echo e(route('wisata.show', ['wisata' => $item['wisata']->id])); ?>" class="btn btn-secondary flex-1">
                                    <i class="fas fa-info-circle mr-2"></i>Lihat Profil
                                </a>
                            <?php endif; ?>

                            <button @click="openDetail = !openDetail" 
                                    class="btn btn-outline btn-primary">
                                <span x-show="!openDetail"><i class="fas fa-chevron-down"></i></span>
                                <span x-show="openDetail"><i class="fas fa-chevron-up"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            
            <div role="alert" class="alert alert-warning shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                <div>
                    <h3 class="font-bold">Perhatian!</h3>
                    <div class="text-xs">
                        Tidak ditemukan rekomendasi wisata yang sesuai.
                        <?php if(session('error')): ?>
                            <br>Error: <?php echo e(session('error')); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="mt-12 text-center">
            <a href="<?php echo e(route('preferensi')); ?>" class="btn btn-primary">
                <i class="fas fa-arrow-left mr-2"></i> Kembali ke Pencarian
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-daisy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PROJECT\mywis_update\resources\views/hasil.blade.php ENDPATH**/ ?>