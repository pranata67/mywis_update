

<?php $__env->startSection('content'); ?>


<div class="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
    <form action="<?php echo e(route('calculate')); ?>" method="POST" id="preferenceForm" class="space-y-8">
        <?php echo csrf_field(); ?>
        
        <h2 class="text-3xl font-bold text-center mb-10">
            Sesuaikan Preferensi Wisata Anda
        </h2>

        
        <div class="card bg-base-200 shadow-xl">
            <div class="card-body">
                <label class="block text-xl font-medium text-center mb-3">Lihat Lokasi Anda Melalui Peta</label>
                <div id="map" class="w-full max-w-4xl h-72 md:h-96 mx-auto rounded-lg shadow-2xl border-2 border-base-300"></div>
            </div>
        </div>

        
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">
                <label for="coordinates_input" class="label">
                    <span class="label-text text-lg">Koordinat Anda</span>
                </label>
                <input type="text" 
                       id="coordinates_input" 
                       name="koordinat" 
                       required 
                       readonly 
                       placeholder="Pilih lokasi pada peta..."
                       class="input input-bordered w-full" />
            </div>
        </div>

        
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">
                <label for="kategori_select" class="label">
                    <span class="label-text text-lg">Pilih Kategori Tempat Wisata</span>
                </label>
                
                <select id="kategori_select" name="kategori" class="select select-bordered w-full">
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->nama_kategori); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">
                 <label class="label">
                    <span class="label-text text-lg">Masukkan Persentase Bobot Prioritas Kriteria</span>
                </label>
                <p class="text-sm opacity-70 mb-4">Total bobot dari semua kriteria harus 100%.</p>
                <input type="hidden" name="kriteria_order" id="kriteria_order">
                
                <div class="overflow-x-auto">
                    
                    <table class="table w-full">
                        <thead>
                            <tr class="bg-base-200">
                                <th>Kriteria</th>
                                <th>Bobot (%)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-id="<?php echo e($kriteria->id); ?>">
                                <td><?php echo e(ucwords(str_replace('_', ' ', $kriteria->nama_kriteria))); ?></td>
                                <td>
                                     
                                     <input type="number"
                                           class="input input-bordered w-28 weight-input"
                                           name="weights[<?php echo e($kriteria->id); ?>]"
                                           min="0"
                                           max="100"
                                           step="1"
                                           required
                                           placeholder="0-100">
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div id="form-error-message" role="alert" class="alert alert-error shadow-lg hidden">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <span></span>
        </div>

        
        <div class="pt-5 text-center">
            <button type="submit" class="btn btn-success w-full sm:w-auto">
                <i class="fas fa-search mr-2"></i>
                Cari Rekomendasi Wisata
            </button>
        </div>
    </form>

    
    <?php if($errors->any()): ?>
        <div role="alert" class="alert alert-error mt-8 shadow-lg">
             <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <div>
                <h3 class="font-bold">Oops! Ada beberapa kesalahan:</h3>
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div>



<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>

<?php
use App\Models\Wisata;
$wisatas = Wisata::all();
?>

<script>
// JavaScript untuk validasi form dan inisialisasi peta tetap sama.
document.addEventListener('DOMContentLoaded', function() {
    const preferenceForm = document.getElementById('preferenceForm');
    const formErrorMessageDiv = document.getElementById('form-error-message');
    const formErrorSpan = formErrorMessageDiv.querySelector('span');

    if (preferenceForm) {
        preferenceForm.addEventListener('submit', function(e) {
            let totalWeight = 0;
            document.querySelectorAll('.weight-input').forEach(input => {
                totalWeight += parseFloat(input.value) || 0;
            });

            formErrorMessageDiv.classList.add('hidden');
            formErrorSpan.textContent = '';

            if (Math.abs(totalWeight - 100) > 0.01) {
                e.preventDefault(); 
                formErrorSpan.textContent = 'Total persentase bobot untuk semua kriteria harus tepat 100%. Mohon periksa kembali.';
                formErrorMessageDiv.classList.remove('hidden');
                formErrorMessageDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
                return false;
            }

            const kriteriaIdsInOrder = <?php echo json_encode($kriterias->pluck('id')->all(), 15, 512) ?>;
            const kriteriaOrderInput = document.querySelector('#kriteria_order');
            if (kriteriaOrderInput) {
                kriteriaOrderInput.value = kriteriaIdsInOrder.join(',');
            }
        });
    }

    var wisataLocations = <?php echo json_encode($wisatas->map(function($wisata) {
        return [
            'coordinates' => $wisata->coordinates, 'name' => $wisata->name
        ];
    }), 512) ?>;

    var map;
    var defaultLat = -7.490675772242737;
    var defaultLng = -7.490675772242737;
    var userLocationMarker;

    function fetchLocationByIp(redIcon) {
        console.log('Mencoba mendapatkan lokasi via IP Geolocation...');
        fetch('https://ip-api.com/json')
            .then(response => response.json())
            .then(data => {
                if (data && data.status === 'success') {
                    var ipLat = data.lat;
                    var ipLng = data.lon;
                    console.log('Berhasil mendapatkan lokasi dari IP:', data.city);
                    map.setView([ipLat, ipLng], 12);
                    userLocationMarker.setLatLng([ipLat, ipLng]);
                    userLocationMarker.bindPopup('Mohon izinkan akses GPS pada browser Anda. (Lokasi saat ini terdeteksi melalui IP Address Anda)').openPopup();
                    $('#coordinates_input').val(ipLat.toFixed(6) + ', ' + ipLng.toFixed(6));
                } else {
                    console.warn('IP Geolocation gagal. Menggunakan lokasi default.');
                    userLocationMarker.bindPopup('Lokasi tidak terdeteksi, menggunakan lokasi default.').openPopup();
                }
            })
            .catch(error => {
                console.error('Error saat fetch IP Geolocation:', error);
                userLocationMarker.bindPopup('Lokasi tidak terdeteksi, menggunakan lokasi default.').openPopup();
            });
    }

    function initMap() {
        if (typeof L === 'undefined') {
            console.error('Leaflet library is not loaded. Map cannot be initialized.');
            const mapDiv = document.getElementById('map');
            if(mapDiv) {
                mapDiv.innerHTML = `<div class="alert alert-error"><p>Pustaka peta (Leaflet) gagal dimuat. Silakan coba muat ulang halaman.</p></div>`;
            }
            return;
        }

        map = L.map('map').setView([defaultLat, defaultLng], 10);

        L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
        }).addTo(map);

        wisataLocations.forEach(function(location) {
            try {
                var coords = location.coordinates.split(/,\s*/);
                if (coords.length === 2 && !isNaN(parseFloat(coords[0])) && !isNaN(parseFloat(coords[1]))) {
                    L.marker([parseFloat(coords[0]), parseFloat(coords[1])])
                        .addTo(map)
                        .bindPopup(L.popup({maxWidth: 200}).setContent(location.name));
                } else {
                    console.warn('Invalid coordinates for wisata:', location.name, location.coordinates);
                }
            } catch (error) {
                console.error('Error processing wisata location:', location.name, error);
            }
        });
        
        var redIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        userLocationMarker = L.marker([defaultLat, defaultLng], { icon: redIcon })
            .addTo(map)
            .bindPopup('Mencari lokasi Anda...')
            .openPopup();
        
        $('#coordinates_input').val(defaultLat.toFixed(6) + ', ' + defaultLng.toFixed(6));

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) { // Success Callback
                    var userLat = position.coords.latitude;
                    var userLng = position.coords.longitude;
                    map.setView([userLat, userLng], 13);
                    userLocationMarker.setLatLng([userLat, userLng]);
                    userLocationMarker.bindPopup('Lokasi Anda Saat Ini').openPopup();
                    $('#coordinates_input').val(userLat.toFixed(6) + ', ' + userLng.toFixed(6));
                },
                function(error) { // Error Callback
                    console.warn('Error getting user location:', error.message);
                    fetchLocationByIp(redIcon);
                },
                { timeout: 10000, enableHighAccuracy: true }
            );
        } else {
            console.warn('Geolocation is not supported by this browser.');
            fetchLocationByIp(redIcon);
        }
        $(window).on('resize', function() {
            setTimeout(function() { map.invalidateSize(); }, 100);
        }).trigger('resize');
    }

    if (typeof L !== 'undefined') {
        initMap();
    } else {
        console.warn('Leaflet not immediately available, will try to init map shortly...');
        setTimeout(function() {
            if (typeof L !== 'undefined') {
                initMap();
            } else {
                 console.error('Leaflet failed to load. Map cannot be initialized.');
                 const mapDiv = document.getElementById('map');
                 if(mapDiv) {
                     mapDiv.innerHTML = `<div class="alert alert-error"><p>Map gagal dimuat. Periksa koneksi internet atau coba muat ulang halaman.</p></div>`;
                 }
            }
        }, 1000);
    }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-daisy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PROJECT\mywis_update\resources\views/preferensi.blade.php ENDPATH**/ ?>